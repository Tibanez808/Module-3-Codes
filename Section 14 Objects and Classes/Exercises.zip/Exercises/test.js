let person = {}

person.name = 'John'

console.log(person)

let cars = {}

cars.audi = 24

console.log(cars)